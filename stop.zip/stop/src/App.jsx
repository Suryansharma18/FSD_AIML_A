import { useState } from 'react'
import Stop from "./stop"
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
  <Stop></Stop>
  )
}

export default App
