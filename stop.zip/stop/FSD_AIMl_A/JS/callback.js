function getdata(){
    setTimeout(() => {
        console.log(" got the data");
    }, 3000);
    
}

function displayData(){
    setTimeout(() => {
        console.log(" got the data");
    }, 3000);
    
}

function login(){
    setTimeout(() => {
        console.log(" got the data");
    }, 3000);
    
}

function register(){
    setTimeout(() => {
        console.log(" got the data");
    }, 3000);
    
}

function sendEmail(){
    setTimeout(() => {
        console.log(" got the data");
    }, 3000);
    
}

login();
register();
getdata();
sendEmail();
displayData();